package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RemoteViews;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;

public class SettingsActivity extends Activity {

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private Impostazioni s;
    private FrameLayout anteprima;
    private LinearLayout boxMeteo;
    private TextView statoMeteo;
    private EditText campoCitta;
    private final List<Spinner> spinnerStile = new ArrayList<>();

    private static final int ACCENTO = 0xFF4C8DFF;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        if (in != null) widgetId = in.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_CANCELED, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        }
        s = Impostazioni.carica(this, widgetId);
        setTitle(widgetId != AppWidgetManager.INVALID_APPWIDGET_ID ? "Personalizza il widget" : "Widget Orologio");
        costruisciUI();
        aggiornaAnteprima();
        aggiornaStatoMeteo();
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private void costruisciUI() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0F1318);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(12), dp(16), dp(32));
        sv.addView(col);

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            TextView info = testo("Per aggiungere il widget: tieni premuto sulla schermata Home → Widget → \"Widget Orologio\". "
                    + "Puoi ridimensionarlo tenendolo premuto. Le modifiche fatte qui valgono per tutti i widget.", 14, 0xFFB8C2CC);
            info.setPadding(0, 0, 0, dp(12));
            col.addView(info);
        }

        // Anteprima
        anteprima = new FrameLayout(this);
        GradientDrawable sf = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF0B1A3A, 0xFF1D4D6E});
        sf.setCornerRadius(dp(18));
        anteprima.setBackground(sf);
        anteprima.setPadding(dp(6), dp(6), dp(6), dp(6));
        col.addView(anteprima, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)));

        // Stili pronti
        col.addView(titolo("Stili pronti"));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout riga = new LinearLayout(this);
        hs.addView(riga);
        for (int i = 0; i < Impostazioni.NOMI_STILI.length; i++) {
            final int n = i;
            Button bt = bottone(Impostazioni.NOMI_STILI[i], false);
            bt.setTypeface(Typeface.create(Impostazioni.FAMIGLIE_FONT[Impostazioni.STILI[i][0]], Typeface.NORMAL));
            bt.setOnClickListener(v -> {
                s.applicaStile(n);
                sincronizzaSpinner();
                aggiornaAnteprima();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(8), 0);
            riga.addView(bt, lp);
        }
        col.addView(hs);

        col.addView(titolo("Contenuto"));
        spinner(col, "Cosa mostrare", Impostazioni.NOMI_MODO, s.modo, v -> {
            s.modo = v;
            boxMeteo.setVisibility(v == 1 ? View.VISIBLE : View.GONE);
        }, false);

        col.addView(titolo("Orologio"));
        spinnerStile.add(spinner(col, "Carattere", Impostazioni.NOMI_FONT, s.font, v -> s.font = v, true));
        spinnerStile.add(spinner(col, "Formato dell'ora", Impostazioni.NOMI_ORA, s.formatoOra, v -> s.formatoOra = v, false));
        spinnerStile.add(spinner(col, "Formato della data", Impostazioni.NOMI_DATA, s.formatoData, v -> s.formatoData = v, false));
        spinnerStile.add(spinner(col, "Posizione della data", Impostazioni.NOMI_POS_DATA, s.posData, v -> s.posData = v, false));

        col.addView(titolo("Aspetto"));
        spinnerStile.add(spinner(col, "Allineamento", Impostazioni.NOMI_ALLINEA, s.allinea, v -> s.allinea = v, false));
        spinnerStile.add(spinner(col, "Colore", Impostazioni.NOMI_COLORI, s.colore, v -> s.colore = v, false));
        spinnerStile.add(spinner(col, "Sfondo", Impostazioni.NOMI_SFONDO, s.sfondo, v -> s.sfondo = v, false));
        spinner(col, "Grandezza del testo", Impostazioni.NOMI_DIM, s.dimensione, v -> s.dimensione = v, false);

        // Meteo
        boxMeteo = new LinearLayout(this);
        boxMeteo.setOrientation(LinearLayout.VERTICAL);
        boxMeteo.addView(titolo("Meteo"));
        spinner(boxMeteo, "Stile del meteo", Impostazioni.NOMI_METEO_STILE, s.meteoStile, v -> s.meteoStile = v, false);
        spinner(boxMeteo, "Posizione del meteo", Impostazioni.NOMI_METEO_POS, s.meteoPos, v -> s.meteoPos = v, false);

        campoCitta = new EditText(this);
        campoCitta.setHint("Scrivi la tua città (es. Matera)");
        campoCitta.setSingleLine(true);
        campoCitta.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        campoCitta.setTextColor(Color.WHITE);
        campoCitta.setHintTextColor(0xFF7A8794);
        campoCitta.setText(Meteo.nomeLuogo(this));
        campoCitta.setOnEditorActionListener((v, a, e) -> { cercaCitta(); return true; });
        boxMeteo.addView(campoCitta);

        LinearLayout bottoni = new LinearLayout(this);
        Button cerca = bottone("🔎 Cerca città", false);
        cerca.setOnClickListener(v -> cercaCitta());
        Button pos = bottone("📍 Usa la mia posizione", false);
        pos.setOnClickListener(v -> usaPosizione());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(0, 0, dp(8), 0);
        bottoni.addView(cerca, lp);
        bottoni.addView(pos, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        boxMeteo.addView(bottoni);

        statoMeteo = testo("", 13, 0xFF9AA7B4);
        statoMeteo.setPadding(0, dp(8), 0, 0);
        boxMeteo.addView(statoMeteo);
        boxMeteo.setVisibility(s.modo == 1 ? View.VISIBLE : View.GONE);
        col.addView(boxMeteo);

        Button salva = bottone("✔ Salva e applica", true);
        salva.setOnClickListener(v -> salva());
        LinearLayout.LayoutParams lps = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        lps.setMargins(0, dp(24), 0, 0);
        col.addView(salva, lps);

        TextView copy = testo("Copyright © Ignazio Paolicelli · Meteo: Open-Meteo", 12, 0xFF5E6B78);
        copy.setGravity(Gravity.CENTER);
        copy.setPadding(0, dp(16), 0, 0);
        col.addView(copy);

        setContentView(sv);
    }

    private TextView testo(String t, float sp, int colore) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(colore);
        return tv;
    }

    private TextView titolo(String t) {
        TextView tv = testo(t, 17, Color.WHITE);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(20), 0, dp(6));
        return tv;
    }

    private Button bottone(String t, boolean principale) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(principale ? ACCENTO : 0xFF222B35);
        b.setBackground(g);
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        return b;
    }

    private Spinner spinner(LinearLayout parent, String etichetta, String[] voci, int sel, IntConsumer azione, boolean conFont) {
        parent.addView(testo(etichetta, 13, 0xFF9AA7B4));
        Spinner sp = new Spinner(this, Spinner.MODE_DIALOG);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, voci) {
            @Override
            public View getView(int pos, View cv, ViewGroup p) {
                return stilizza(super.getView(pos, cv, p), pos, false);
            }

            @Override
            public View getDropDownView(int pos, View cv, ViewGroup p) {
                return stilizza(super.getDropDownView(pos, cv, p), pos, true);
            }

            private View stilizza(View v, int pos, boolean menu) {
                if (v instanceof TextView) {
                    TextView tv = (TextView) v;
                    tv.setTextSize(16);
                    tv.setTextColor(Color.WHITE);
                    if (menu) tv.setPadding(dp(18), dp(14), dp(18), dp(14));
                    tv.setTypeface(conFont ? Typeface.create(Impostazioni.FAMIGLIE_FONT[pos], Typeface.NORMAL) : Typeface.DEFAULT);
                }
                return v;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setSelection(Math.max(0, Math.min(sel, voci.length - 1)), false);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(0xFF1A222B);
        sp.setBackground(g);
        sp.setPadding(dp(6), dp(4), dp(6), dp(4));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> a, View v, int pos, long id) {
                azione.accept(pos);
                aggiornaAnteprima();
            }

            @Override
            public void onNothingSelected(AdapterView<?> a) {
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(0, dp(4), 0, dp(10));
        parent.addView(sp, lp);
        return sp;
    }

    /** Dopo uno stile pronto, allinea le tendine ai nuovi valori */
    private void sincronizzaSpinner() {
        int[] v = {s.font, s.formatoOra, s.formatoData, s.posData, s.allinea, s.colore, s.sfondo};
        for (int i = 0; i < spinnerStile.size() && i < v.length; i++) spinnerStile.get(i).setSelection(v[i], false);
    }

    private void aggiornaAnteprima() {
        if (anteprima == null) return;
        anteprima.post(() -> {
            try {
                anteprima.removeAllViews();
                float dens = getResources().getDisplayMetrics().density;
                float w = Math.max(200, anteprima.getWidth() / dens - 12);
                float h = 208;
                RemoteViews rv = OrologioWidget.costruisci(this, s, w, h, 0);
                View v = rv.apply(this, anteprima);
                anteprima.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            } catch (Exception e) {
                // l'anteprima non è essenziale
            }
        });
    }

    private void aggiornaStatoMeteo() {
        if (statoMeteo == null) return;
        if (!Meteo.haPosizione(this)) {
            statoMeteo.setText("Nessuna città impostata.");
            return;
        }
        String t = "Città: " + Meteo.nomeLuogo(this);
        long u = Meteo.ultimoAggiornamento(this);
        if (u > 0) t += "\n" + Meteo.breve(this) + "  " + Meteo.dettagli(this)
                + "\nAggiornato alle " + DateFormat.format("HH:mm", u) + " (si aggiorna ogni 30 min, tocca il meteo nel widget per aggiornarlo subito)";
        statoMeteo.setText(t);
    }

    private void cercaCitta() {
        final String nome = campoCitta.getText().toString().trim();
        if (nome.isEmpty()) {
            Toast.makeText(this, "Scrivi il nome di una città", Toast.LENGTH_SHORT).show();
            return;
        }
        statoMeteo.setText("Cerco \"" + nome + "\"…");
        new Thread(() -> {
            String msg;
            try {
                String trovato = Meteo.cercaCitta(this, nome);
                if (trovato == null) msg = "Città non trovata.";
                else {
                    Meteo.aggiorna(this, true);
                    msg = null;
                }
            } catch (Exception e) {
                msg = "Errore di connessione. Controlla internet.";
            }
            final String m = msg;
            runOnUiThread(() -> {
                if (m != null) statoMeteo.setText(m);
                else {
                    campoCitta.setText(Meteo.nomeLuogo(this));
                    aggiornaStatoMeteo();
                    aggiornaAnteprima();
                }
            });
        }).start();
    }

    private void usaPosizione() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 7);
            return;
        }
        LocationManager lm = getSystemService(LocationManager.class);
        if (lm == null) return;
        Location migliore = null;
        for (String p : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (migliore == null || l.getTime() > migliore.getTime())) migliore = l;
            } catch (SecurityException ignored) {
            }
        }
        if (migliore != null && System.currentTimeMillis() - migliore.getTime() < 6 * 3600 * 1000L) {
            usaLocation(migliore);
            return;
        }
        String prov = null;
        if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) prov = LocationManager.NETWORK_PROVIDER;
        else if (lm.getProviders(true).contains("fused")) prov = "fused";
        if (prov == null) {
            if (migliore != null) usaLocation(migliore);
            else statoMeteo.setText("Attiva la localizzazione del telefono, oppure scrivi la città.");
            return;
        }
        statoMeteo.setText("Cerco la tua posizione…");
        try {
            lm.requestLocationUpdates(prov, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location l) {
                    lm.removeUpdates(this);
                    usaLocation(l);
                }

                @Override
                public void onStatusChanged(String p, int st, Bundle e) {
                }

                @Override
                public void onProviderEnabled(String p) {
                }

                @Override
                public void onProviderDisabled(String p) {
                }
            }, Looper.getMainLooper());
        } catch (SecurityException e) {
            statoMeteo.setText("Permesso posizione negato.");
        }
    }

    private void usaLocation(Location l) {
        statoMeteo.setText("Scarico il meteo…");
        new Thread(() -> {
            String nome = "Posizione attuale";
            try {
                List<Address> a = new Geocoder(this, Locale.getDefault()).getFromLocation(l.getLatitude(), l.getLongitude(), 1);
                if (a != null && !a.isEmpty()) {
                    String loc = a.get(0).getLocality();
                    if (loc == null) loc = a.get(0).getSubAdminArea();
                    if (loc != null) nome = loc;
                }
            } catch (Exception ignored) {
            }
            Meteo.salvaPosizione(this, l.getLatitude(), l.getLongitude(), nome);
            boolean ok = Meteo.aggiorna(this, true);
            runOnUiThread(() -> {
                campoCitta.setText(Meteo.nomeLuogo(this));
                aggiornaStatoMeteo();
                if (!ok) statoMeteo.append("\nNon riesco a scaricare il meteo ora.");
                aggiornaAnteprima();
            });
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perm, int[] res) {
        super.onRequestPermissionsResult(req, perm, res);
        if (req == 7 && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) usaPosizione();
        else if (req == 7) statoMeteo.setText("Senza permesso: scrivi la città e premi Cerca.");
    }

    private void salva() {
        AppWidgetManager mgr = AppWidgetManager.getInstance(this);
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            s.salva(this, widgetId);
            OrologioWidget.disegna(this, mgr, widgetId);
            setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        } else {
            s.salva(this, 0);
            for (int id : OrologioWidget.ids(this)) s.salva(this, id);
            OrologioWidget.aggiornaTutti(this);
            Toast.makeText(this, "Applicato a tutti i widget", Toast.LENGTH_SHORT).show();
        }
        if (s.modo == 1 && Meteo.haPosizione(this)) {
            sendBroadcast(new Intent(this, OrologioWidget.class).setAction(OrologioWidget.AZIONE_AGGIORNA));
        }
        finish();
    }
}
