package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;

public class OrologioWidget extends AppWidgetProvider {

    public static final String AZIONE_AGGIORNA = "it.paolicelli.widgetorologio.AGGIORNA";
    public static final String AZIONE_MEZZANOTTE = "it.paolicelli.widgetorologio.MEZZANOTTE";

    @Override
    public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        aggiornaTutti(c);
        programmaMezzanotte(c);
        scaricaMeteo(c, false, goAsync());
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager mgr, int id, Bundle opzioni) {
        disegna(c, mgr, id); // ridimensionamento
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        for (int id : ids) Impostazioni.cancella(c, id);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (AZIONE_AGGIORNA.equals(a)) {
            aggiornaTutti(c);
            scaricaMeteo(c, true, goAsync());
        } else if (AZIONE_MEZZANOTTE.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_LOCALE_CHANGED.equals(a)) {
            aggiornaTutti(c);
            programmaMezzanotte(c);
        }
    }

    private static void scaricaMeteo(Context c, boolean forza, PendingResult pr) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                if (serveMeteo(app) && Meteo.aggiorna(app, forza)) aggiornaTutti(app);
            } finally {
                if (pr != null) pr.finish();
            }
        }).start();
    }

    static int[] ids(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, OrologioWidget.class));
    }

    static boolean serveMeteo(Context c) {
        for (int id : ids(c)) if (Impostazioni.carica(c, id).modo == 1) return true;
        return false;
    }

    public static void aggiornaTutti(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        for (int id : ids(c)) disegna(c, mgr, id);
    }

    public static void disegna(Context c, AppWidgetManager mgr, int id) {
        Bundle o = mgr.getAppWidgetOptions(id);
        int w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (w <= 0) w = 300;
        if (h <= 0) h = 160;
        mgr.updateAppWidget(id, costruisci(c, Impostazioni.carica(c, id), w, h, id));
    }

    /** Crea la grafica del widget. wDp/hDp = dimensioni in dp. id <= 0 = anteprima. */
    public static RemoteViews costruisci(Context c, Impostazioni s, float wDp, float hDp, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), Impostazioni.LAYOUT_FONT[s.font]);
        int colore = Impostazioni.COLORI[s.colore];
        int coloreTenue = (colore & 0x00FFFFFF) | 0xD9000000;
        int[] grav = {Gravity.START | Gravity.CENTER_VERTICAL, Gravity.CENTER, Gravity.END | Gravity.CENTER_VERTICAL};
        int g = grav[s.allinea];
        int gTesto = s.allinea == 0 ? Gravity.START : s.allinea == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.END;

        rv.setInt(R.id.radice, "setGravity", g);
        rv.setInt(R.id.radice, "setBackgroundResource", Impostazioni.SFONDI[s.sfondo]);

        // Ora
        String fo = Impostazioni.FORMATI_ORA[s.formatoOra];
        rv.setCharSequence(R.id.ora, "setFormat24Hour", fo);
        rv.setCharSequence(R.id.ora, "setFormat12Hour", fo);
        rv.setInt(R.id.ora, "setGravity", gTesto);
        rv.setTextColor(R.id.ora, colore);

        // Data (+ meteo accanto alla data, se scelto)
        boolean meteo = s.modo == 1;
        boolean haPos = Meteo.haPosizione(c);
        String breve = Meteo.breve(c);
        if (id <= 0 && breve.isEmpty()) breve = "☀️ 18°"; // esempio in anteprima
        String data = Impostazioni.testoData(s.formatoData);
        boolean meteoInData = meteo && s.meteoPos == 1;
        if (meteoInData && !breve.isEmpty()) data = data.isEmpty() ? breve : data + "  " + breve;

        int idData = s.posData == 0 ? R.id.data_sopra : R.id.data_sotto;
        int idAltra = s.posData == 0 ? R.id.data_sotto : R.id.data_sopra;
        rv.setViewVisibility(idAltra, View.GONE);
        rv.setViewVisibility(idData, data.isEmpty() ? View.GONE : View.VISIBLE);
        rv.setTextViewText(idData, data);
        rv.setTextColor(idData, coloreTenue);

        // Meteo sotto l'ora
        boolean meteoSotto = meteo && s.meteoPos == 0;
        boolean dettagli = meteoSotto && s.meteoStile == 1;
        String riga1 = breve;
        String riga2 = dettagli ? Meteo.dettagli(c) : "";
        if (id <= 0 && dettagli && riga2.isEmpty()) riga2 = "Sereno · Roma  ↑21° ↓10°";
        if (meteo && !haPos && id > 0) { riga1 = "📍 Tocca per scegliere la città"; riga2 = ""; }
        if (meteoInData && !haPos && id > 0) meteoSotto = true;
        rv.setViewVisibility(R.id.meteo_1, meteoSotto && !riga1.isEmpty() ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(R.id.meteo_2, meteoSotto && !riga2.isEmpty() ? View.VISIBLE : View.GONE);
        rv.setTextViewText(R.id.meteo_1, riga1);
        rv.setTextViewText(R.id.meteo_2, riga2);
        rv.setTextColor(R.id.meteo_1, colore);
        rv.setTextColor(R.id.meteo_2, coloreTenue);

        // Dimensioni del testo in base alla grandezza del widget
        boolean verticale = s.formatoOra == 4;
        float lineeOra = verticale ? 2f : 1f;
        float caratteri = verticale ? 2f : (s.formatoOra == 3 ? 8f : 5f);
        float hData = data.isEmpty() ? 0f : 0.30f;
        float hMeteo = 0f;
        if (meteoSotto) hMeteo = 0.40f + (riga2.isEmpty() ? 0f : 0.26f);
        float daAltezza = (hDp - 24f) / (lineeOra * 1.0f + (hData + hMeteo) * 1.25f);
        float daLarghezza = (wDp - 24f) / (caratteri * 0.62f);
        float t = Math.min(daAltezza, daLarghezza) * Impostazioni.DIM[s.dimensione];
        t = Math.max(16f, Math.min(t, 240f));
        rv.setTextViewTextSize(R.id.ora, TypedValue.COMPLEX_UNIT_DIP, t);
        rv.setTextViewTextSize(idData, TypedValue.COMPLEX_UNIT_DIP, Math.max(11f, t * 0.28f));
        rv.setTextViewTextSize(R.id.meteo_1, TypedValue.COMPLEX_UNIT_DIP, Math.max(12f, t * 0.36f));
        rv.setTextViewTextSize(R.id.meteo_2, TypedValue.COMPLEX_UNIT_DIP, Math.max(10f, t * 0.22f));

        // Tocchi
        if (id > 0) {
            Intent apri = new Intent(c, SettingsActivity.class)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .setData(Uri.parse("widget://" + id))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent piApri = PendingIntent.getActivity(c, id, apri,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.radice, piApri);

            PendingIntent piMeteo = piApri;
            if (haPos) {
                Intent agg = new Intent(c, OrologioWidget.class).setAction(AZIONE_AGGIORNA);
                piMeteo = PendingIntent.getBroadcast(c, 0, agg,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            }
            rv.setOnClickPendingIntent(R.id.meteo_1, piMeteo);
            rv.setOnClickPendingIntent(R.id.meteo_2, piMeteo);
        }
        return rv;
    }

    /** Aggiorna la data subito dopo mezzanotte */
    static void programmaMezzanotte(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 5);
        cal.set(Calendar.MILLISECOND, 0);
        Intent i = new Intent(c, OrologioWidget.class).setAction(AZIONE_MEZZANOTTE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 999, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }
}
