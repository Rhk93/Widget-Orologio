package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;

public class OrologioWidget extends AppWidgetProvider {

    public static final String AZIONE_AGGIORNA = "it.paolicelli.widgetorologio.AGGIORNA";
    public static final String AZIONE_MEZZANOTTE = "it.paolicelli.widgetorologio.MEZZANOTTE";

    @Override
    public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        aggiornaTutti(c);
        programmaMezzanotte(c);
        scaricaMeteo(c, false, goAsync());
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager mgr, int id, Bundle opzioni) {
        disegna(c, mgr, id); // ridimensionamento
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        for (int id : ids) Impostazioni.cancella(c, id);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (AZIONE_AGGIORNA.equals(a)) {
            aggiornaTutti(c);
            scaricaMeteo(c, true, goAsync());
        } else if (AZIONE_MEZZANOTTE.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_LOCALE_CHANGED.equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            aggiornaTutti(c);
            programmaMezzanotte(c);
        }
    }

    private static void scaricaMeteo(Context c, boolean forza, PendingResult pr) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                if (serveMeteo(app) && Meteo.aggiorna(app, forza)) aggiornaTutti(app);
            } finally {
                if (pr != null) pr.finish();
            }
        }).start();
    }

    static int[] ids(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, OrologioWidget.class));
    }

    static boolean serveMeteo(Context c) {
        for (int id : ids(c)) if (Impostazioni.carica(c, id).modo == 1) return true;
        return false;
    }

    public static void aggiornaTutti(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        for (int id : ids(c)) disegna(c, mgr, id);
    }

    public static void disegna(Context c, AppWidgetManager mgr, int id) {
        Bundle o = mgr.getAppWidgetOptions(id);
        int w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (w <= 0) w = 300;
        if (h <= 0) h = 160;
        mgr.updateAppWidget(id, costruisci(c, Impostazioni.carica(c, id), w, h, id));
    }

    /** Crea la grafica del widget. wDp/hDp = dimensioni in dp. id <= 0 = anteprima. */
    public static RemoteViews costruisci(Context c, Impostazioni s, float wDp, float hDp, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), s.layout());
        float dens = c.getResources().getDisplayMetrics().density;
        int colore = s.coloreOra();
        int colore2 = s.coloreSecondario();
        int[] grav = {Gravity.START | Gravity.CENTER_VERTICAL, Gravity.CENTER, Gravity.END | Gravity.CENTER_VERTICAL};
        int gTesto = s.allinea == 0 ? Gravity.START : s.allinea == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.END;

        rv.setInt(R.id.radice, "setGravity", grav[s.allinea]);
        rv.setInt(R.id.radice, "setBackgroundResource", Impostazioni.SFONDI[s.sfondo]);

        // Margini e spostamento (al punto)
        int m = s.margine;
        int pl = m + Math.max(0, s.spostaX), pr = m + Math.max(0, -s.spostaX);
        int pt = m + Math.max(0, s.spostaY), pb = m + Math.max(0, -s.spostaY);
        rv.setViewPadding(R.id.radice, px(pl, dens), px(pt, dens), px(pr, dens), px(pb, dens));
        float wUtile = Math.max(30f, wDp - pl - pr);
        float hUtile = Math.max(30f, hDp - pt - pb);

        // Ora
        String fo = Impostazioni.FORMATI_ORA[s.formatoOra];
        rv.setCharSequence(R.id.ora, "setFormat24Hour", fo);
        rv.setCharSequence(R.id.ora, "setFormat12Hour", fo);
        rv.setInt(R.id.ora, "setGravity", gTesto);
        rv.setTextColor(R.id.ora, colore);
        rv.setViewPadding(R.id.ora, 0, px(s.spazio, dens), 0, px(s.spazio, dens));

        // Data (+ meteo accanto alla data, se scelto)
        boolean meteo = s.modo == 1;
        boolean haPos = Meteo.haPosizione(c);
        String temp = Meteo.breve(c);
        int icona = Meteo.iconaRes(c);
        if (id <= 0 && temp.isEmpty()) { temp = "18°"; icona = R.drawable.meteo_sole; } // esempio in anteprima
        String data = Impostazioni.testoData(s.formatoData);
        boolean meteoInData = meteo && s.meteoPos == 1 && !temp.isEmpty();

        int rigaData = s.posData == 0 ? R.id.riga_sopra : R.id.riga_sotto;
        int rigaAltra = s.posData == 0 ? R.id.riga_sotto : R.id.riga_sopra;
        int idData = s.posData == 0 ? R.id.data_sopra : R.id.data_sotto;
        int idIco = s.posData == 0 ? R.id.ico_sopra : R.id.ico_sotto;
        int idTemp = s.posData == 0 ? R.id.temp_sopra : R.id.temp_sotto;
        rv.setViewVisibility(rigaAltra, View.GONE);
        boolean rigaVisibile = !data.isEmpty() || meteoInData;
        rv.setViewVisibility(rigaData, rigaVisibile ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(idData, data.isEmpty() ? View.GONE : View.VISIBLE);
        rv.setTextViewText(idData, data);
        rv.setTextColor(idData, colore2);
        rv.setViewVisibility(idIco, meteoInData ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(idTemp, meteoInData ? View.VISIBLE : View.GONE);
        rv.setTextViewText(idTemp, temp);
        rv.setTextColor(idTemp, colore2);

        // Meteo sotto l'ora
        boolean meteoSotto = meteo && !meteoInData;
        String riga1 = temp;
        boolean conIcona = !temp.isEmpty();
        String riga2 = meteoSotto && s.meteoStile == 1 ? Meteo.dettagli(c) : "";
        if (id <= 0 && meteoSotto && s.meteoStile == 1 && riga2.isEmpty()) riga2 = "Sereno · Roma  ↑21° ↓10°";
        if (meteoSotto && !haPos && id > 0) { riga1 = "📍 Tocca per scegliere la città"; riga2 = ""; conIcona = false; }
        boolean v1 = meteoSotto && !riga1.isEmpty(), v2 = meteoSotto && !riga2.isEmpty();
        rv.setViewVisibility(R.id.meteo_box, v1 ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(R.id.meteo_icona, conIcona ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(R.id.meteo_2, v2 ? View.VISIBLE : View.GONE);
        rv.setTextViewText(R.id.meteo_1, riga1);
        rv.setTextViewText(R.id.meteo_2, riga2);
        rv.setTextColor(R.id.meteo_1, colore);
        rv.setTextColor(R.id.meteo_2, colore2);

        // Dimensioni: si adattano al widget, poi le percentuali scelte
        float sd = s.scalaData / 100f, sm = s.scalaMeteo / 100f;
        boolean verticale = s.formatoOra == 4;
        float lineeOra = verticale ? 2f : 1f;
        float caratteri = verticale ? 2f : (s.formatoOra == 3 ? 8f : 5f);
        float hRighe = lineeOra * 1.0f;
        if (rigaVisibile) hRighe += 0.28f * sd * 1.4f;
        if (v1) hRighe += 0.36f * sm * 1.45f;
        if (v2) hRighe += 0.22f * sm * 1.4f;
        float daAltezza = (hUtile - 2f * s.spazio - 6f) / hRighe;
        float daLarghezza = wUtile / (caratteri * 0.62f);
        float t = Math.min(daAltezza, daLarghezza) * (s.scala / 100f);
        t = Math.max(8f, Math.min(t, 400f));

        String testoRiga = data + (meteoInData ? "    " + temp : "");
        float tData = Math.min(Math.max(8f, t * 0.28f * sd), larghezzaMax(testoRiga, wUtile));
        float tM1 = Math.min(Math.max(9f, t * 0.36f * sm), larghezzaMax((conIcona ? "  " : "") + riga1, wUtile));
        float tM2 = Math.min(Math.max(8f, t * 0.22f * sm), larghezzaMax(riga2, wUtile));
        rv.setTextViewTextSize(R.id.ora, TypedValue.COMPLEX_UNIT_DIP, t);
        rv.setTextViewTextSize(idData, TypedValue.COMPLEX_UNIT_DIP, tData);
        rv.setTextViewTextSize(idTemp, TypedValue.COMPLEX_UNIT_DIP, tData);
        rv.setTextViewTextSize(R.id.meteo_1, TypedValue.COMPLEX_UNIT_DIP, tM1);
        rv.setTextViewTextSize(R.id.meteo_2, TypedValue.COMPLEX_UNIT_DIP, tM2);

        // Icone meteo disegnate alla grandezza giusta
        if (meteoInData) rv.setImageViewBitmap(idIco, disegnaIcona(c, icona, tData * 1.2f * dens, s.colore == 1));
        if (conIcona && v1) rv.setImageViewBitmap(R.id.meteo_icona, disegnaIcona(c, icona, tM1 * 1.25f * dens, s.colore == 1));

        // Tocchi: ora → sveglia, data → calendario, meteo → app meteo, resto → impostazioni
        if (id > 0) {
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
            Intent apri = new Intent(c, SettingsActivity.class)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .setData(Uri.parse("widget://" + id))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent piApri = PendingIntent.getActivity(c, id * 10, apri, fl);
            rv.setOnClickPendingIntent(R.id.radice, piApri);

            PendingIntent piSveglia = PendingIntent.getActivity(c, id * 10 + 1, apri(c, "sveglia"), fl);
            rv.setOnClickPendingIntent(R.id.ora, piSveglia);

            PendingIntent piCal = PendingIntent.getActivity(c, id * 10 + 2, apri(c, "calendario"), fl);
            rv.setOnClickPendingIntent(R.id.data_sopra, piCal);
            rv.setOnClickPendingIntent(R.id.data_sotto, piCal);

            PendingIntent piMeteo = haPos ? PendingIntent.getActivity(c, id * 10 + 3, apri(c, "meteo"), fl) : piApri;
            rv.setOnClickPendingIntent(R.id.meteo_box, piMeteo);
            rv.setOnClickPendingIntent(R.id.meteo_2, piMeteo);
            rv.setOnClickPendingIntent(R.id.ico_sopra, piMeteo);
            rv.setOnClickPendingIntent(R.id.temp_sopra, piMeteo);
            rv.setOnClickPendingIntent(R.id.ico_sotto, piMeteo);
            rv.setOnClickPendingIntent(R.id.temp_sotto, piMeteo);
        }
        return rv;
    }

    private static Intent apri(Context c, String cosa) {
        return new Intent(c, ApriActivity.class).putExtra("cosa", cosa)
                .setData(Uri.parse("apri://" + cosa))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
    }

    private static android.graphics.Bitmap disegnaIcona(Context c, int res, float pixel, boolean scuro) {
        c = new android.view.ContextThemeWrapper(c, scuro ? R.style.IconeScure : R.style.IconeChiare);
        int n = Math.max(8, Math.min(600, Math.round(pixel)));
        android.graphics.Bitmap bm = android.graphics.Bitmap.createBitmap(n, n, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.drawable.Drawable d = c.getDrawable(res);
        if (d != null) {
            d.setBounds(0, 0, n, n);
            d.draw(new android.graphics.Canvas(bm));
        }
        return bm;
    }

    private static int px(float dp, float dens) {
        return Math.round(dp * dens);
    }

    /** Grandezza massima perché il testo stia in una riga (le emoji contano doppio) */
    private static float larghezzaMax(String testo, float larghezza) {
        if (testo == null || testo.isEmpty()) return 999f;
        int n = 0;
        for (int i = 0; i < testo.length(); ) {
            int cp = testo.codePointAt(i);
            n += cp > 0x2000 && !Character.isLetterOrDigit(cp) ? 2 : 1;
            i += Character.charCount(cp);
        }
        return Math.max(8f, (larghezza - 8f) / (n * 0.56f));
    }

    /** Aggiorna la data subito dopo mezzanotte */
    static void programmaMezzanotte(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 5);
        cal.set(Calendar.MILLISECOND, 0);
        Intent i = new Intent(c, OrologioWidget.class).setAction(AZIONE_MEZZANOTTE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 999, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }
}
