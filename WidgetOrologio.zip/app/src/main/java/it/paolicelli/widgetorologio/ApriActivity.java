package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli
// Apre Sveglia, Calendario o Meteo nel momento del tocco, provando più app finché una si apre.

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.widget.Toast;

public class ApriActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String cosa = getIntent().getStringExtra("cosa");
        boolean ok;
        if ("sveglia".equals(cosa)) {
            ok = prova(app("com.sec.android.app.clockpackage"),
                    new Intent(AlarmClock.ACTION_SHOW_ALARMS),
                    app("com.google.android.deskclock"),
                    app("com.android.deskclock"));
        } else if ("calendario".equals(cosa)) {
            ok = prova(app("com.samsung.android.calendar"),
                    Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR),
                    app("com.google.android.calendar"));
        } else {
            ok = prova(app("com.sec.android.daemonapp"), app("com.google.android.apps.weather"),
                    app("com.huawei.android.totemweather"), app("com.miui.weather2"), app("com.oneplus.weather"),
                    app("com.coloros.weather2"), app("com.accuweather.android"), app("com.weather.Weather"),
                    new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="
                            + Uri.encode("meteo " + Meteo.nomeLuogo(this)))));
        }
        if (!ok) Toast.makeText(this, "Non trovo un'app da aprire", Toast.LENGTH_SHORT).show();
        finish();
        overridePendingTransition(0, 0);
    }

    private Intent app(String pacchetto) {
        return getPackageManager().getLaunchIntentForPackage(pacchetto);
    }

    private boolean prova(Intent... lista) {
        for (Intent i : lista) {
            if (i == null) continue;
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }
}
