package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli
// Dati meteo gratuiti da Open-Meteo (nessuna chiave richiesta)

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

public class Meteo {

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("meteo", Context.MODE_PRIVATE);
    }

    public static boolean haPosizione(Context c) {
        return p(c).contains("lat");
    }

    public static String nomeLuogo(Context c) {
        return p(c).getString("luogo", "");
    }

    public static void salvaPosizione(Context c, double lat, double lon, String nome) {
        p(c).edit().putFloat("lat", (float) lat).putFloat("lon", (float) lon)
                .putString("luogo", nome).putLong("ultimo", 0).apply();
    }

    /** Cerca una città per nome. Ritorna il nome trovato o null. */
    public static String cercaCitta(Context c, String nome) throws Exception {
        String url = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=it&name="
                + URLEncoder.encode(nome.trim(), "UTF-8");
        JSONObject j = new JSONObject(scarica(url));
        JSONArray r = j.optJSONArray("results");
        if (r == null || r.length() == 0) return null;
        JSONObject o = r.getJSONObject(0);
        String trovato = o.optString("name", nome);
        salvaPosizione(c, o.getDouble("latitude"), o.getDouble("longitude"), trovato);
        return trovato;
    }

    /** Scarica il meteo. Se forza=false lo fa solo se i dati hanno più di 20 minuti. */
    public static boolean aggiorna(Context c, boolean forza) {
        SharedPreferences sp = p(c);
        if (!sp.contains("lat")) return false;
        long ora = System.currentTimeMillis();
        if (!forza && ora - sp.getLong("ultimo", 0) < 20 * 60 * 1000L) return false;
        try {
            String url = String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                            + "&current=temperature_2m,weather_code,is_day"
                            + "&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto",
                    sp.getFloat("lat", 0), sp.getFloat("lon", 0));
            JSONObject j = new JSONObject(scarica(url));
            JSONObject cur = j.getJSONObject("current");
            JSONObject day = j.getJSONObject("daily");
            sp.edit()
                    .putFloat("temp", (float) cur.getDouble("temperature_2m"))
                    .putInt("codice", cur.getInt("weather_code"))
                    .putBoolean("giorno", cur.optInt("is_day", 1) == 1)
                    .putFloat("max", (float) day.getJSONArray("temperature_2m_max").getDouble(0))
                    .putFloat("min", (float) day.getJSONArray("temperature_2m_min").getDouble(0))
                    .putLong("ultimo", ora)
                    .apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean haDati(Context c) {
        return p(c).contains("temp") && p(c).getLong("ultimo", 0) > 0;
    }

    /** "☀️ 18°" */
    public static String breve(Context c) {
        if (!haDati(c)) return "";
        SharedPreferences sp = p(c);
        return icona(sp.getInt("codice", 0), sp.getBoolean("giorno", true)) + " "
                + Math.round(sp.getFloat("temp", 0)) + "°";
    }

    /** "Sereno · Roma  ↑21° ↓10°" */
    public static String dettagli(Context c) {
        if (!haDati(c)) return "";
        SharedPreferences sp = p(c);
        String luogo = sp.getString("luogo", "");
        return descrizione(sp.getInt("codice", 0)) + (luogo.isEmpty() ? "" : " · " + luogo)
                + "  ↑" + Math.round(sp.getFloat("max", 0)) + "° ↓" + Math.round(sp.getFloat("min", 0)) + "°";
    }

    public static long ultimoAggiornamento(Context c) {
        return p(c).getLong("ultimo", 0);
    }

    static String icona(int k, boolean giorno) {
        if (k == 0) return giorno ? "☀️" : "🌙";
        if (k == 1) return giorno ? "🌤️" : "🌙";
        if (k == 2) return giorno ? "⛅" : "☁️";
        if (k == 3) return "☁️";
        if (k == 45 || k == 48) return "🌫️";
        if (k >= 51 && k <= 57) return "🌦️";
        if (k >= 61 && k <= 67) return "🌧️";
        if (k >= 71 && k <= 77) return "❄️";
        if (k >= 80 && k <= 82) return "🌦️";
        if (k == 85 || k == 86) return "🌨️";
        if (k >= 95) return "⛈️";
        return "🌡️";
    }

    static String descrizione(int k) {
        if (k == 0) return "Sereno";
        if (k == 1) return "Poco nuvoloso";
        if (k == 2) return "Parz. nuvoloso";
        if (k == 3) return "Nuvoloso";
        if (k == 45 || k == 48) return "Nebbia";
        if (k >= 51 && k <= 55) return "Pioviggine";
        if (k == 56 || k == 57) return "Pioviggine gelata";
        if (k == 61 || k == 63) return "Pioggia";
        if (k == 65) return "Pioggia forte";
        if (k == 66 || k == 67) return "Pioggia gelata";
        if (k >= 71 && k <= 77) return "Neve";
        if (k >= 80 && k <= 82) return "Rovesci";
        if (k == 85 || k == 86) return "Rovesci di neve";
        if (k == 95) return "Temporale";
        if (k >= 96) return "Temporale e grandine";
        return "Meteo";
    }

    static String scarica(String indirizzo) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(indirizzo).openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(8000);
        try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"))) {
            StringBuilder b = new StringBuilder();
            String riga;
            while ((riga = r.readLine()) != null) b.append(riga);
            return b.toString();
        } finally {
            con.disconnect();
        }
    }
}
