package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Impostazioni {

    // ---------- Caratteri ----------
    public static final String[] NOMI_FONT = {
            "Medio", "Sottile", "Leggero", "Condensato", "Serif",
            "Digitale", "Corsivo", "Casual", "Extra grassetto", "Maiuscoletto", "Normale"};
    public static final String[] FAMIGLIE_FONT = {
            "sans-serif-medium", "sans-serif-thin", "sans-serif-light", "sans-serif-condensed", "serif",
            "monospace", "cursive", "casual", "sans-serif-black", "sans-serif-smallcaps", "sans-serif"};
    static final int[] LAYOUT_OMBRA = {
            R.layout.widget_f0, R.layout.widget_f1, R.layout.widget_f2, R.layout.widget_f3, R.layout.widget_f4,
            R.layout.widget_f5, R.layout.widget_f6, R.layout.widget_f7, R.layout.widget_f8, R.layout.widget_f9, R.layout.widget_f10};
    static final int[] LAYOUT_PIATTO = {
            R.layout.widget_f0_piatto, R.layout.widget_f1_piatto, R.layout.widget_f2_piatto, R.layout.widget_f3_piatto,
            R.layout.widget_f4_piatto, R.layout.widget_f5_piatto, R.layout.widget_f6_piatto, R.layout.widget_f7_piatto,
            R.layout.widget_f8_piatto, R.layout.widget_f9_piatto, R.layout.widget_f10_piatto};

    /** Con lo sfondo trasparente il testo ha l'ombra, con un riquadro no */
    public int layout() {
        return sfondo == 0 ? LAYOUT_OMBRA[font] : LAYOUT_PIATTO[font];
    }

    // ---------- Ora e data ----------
    public static final String[] NOMI_ORA = {"24 ore (09:41)", "24 ore (9:41)", "12 ore (9:41)", "Con i secondi", "Verticale (ore sopra, minuti sotto)"};
    public static final String[] FORMATI_ORA = {"HH:mm", "H:mm", "h:mm", "HH:mm:ss", "HH\nmm"};

    public static final String[] NOMI_DATA = {"Mar, 17 Nov", "Martedì 17 novembre", "MAR 17 NOV", "17/11/2026",
            "Martedì", "Nessuna data", "MARTEDÌ", "martedì 17 novembre", "Mar 17"};
    public static final String[] NOMI_POS_DATA = {"Sopra l'ora", "Sotto l'ora"};
    public static final String[] NOMI_ALLINEA = {"A sinistra", "Al centro", "A destra"};

    // ---------- Colori ----------
    public static final String[] NOMI_COLORI = {"Bianco", "Nero", "Grigio iOS", "Grigio chiaro", "Rosso iOS",
            "Arancione iOS", "Giallo iOS", "Verde iOS", "Azzurro iOS", "Blu iOS", "Blu Samsung", "Viola iOS",
            "Rosa iOS", "Oro", "Menta", "Corallo"};
    public static final int[] COLORI = {0xFFFFFFFF, 0xFF111111, 0xFF8E8E93, 0xFFD1D1D6, 0xFFFF3B30,
            0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF5AC8FA, 0xFF0A84FF, 0xFF3E91FF, 0xFFAF52DE,
            0xFFFF2D55, 0xFFE8C66A, 0xFF63E6BE, 0xFFFF7A6B};

    public static String[] nomiColoriSecondari() {
        String[] r = new String[NOMI_COLORI.length + 1];
        r[0] = "Come l'ora";
        System.arraycopy(NOMI_COLORI, 0, r, 1, NOMI_COLORI.length);
        return r;
    }

    public int coloreOra() {
        return COLORI[colore];
    }

    public int coloreSecondario() {
        if (coloreData > 0) return COLORI[coloreData - 1];
        return (COLORI[colore] & 0x00FFFFFF) | 0xE0000000;
    }

    // ---------- Sfondi ----------
    public static final String[] NOMI_SFONDO = {"Nessuno", "Vetro scuro", "Vetro chiaro", "Grafite iOS", "Bianco iOS",
            "Nero", "Blu notte", "Blu Samsung", "Sabbia", "Grigio scuro"};
    public static final int[] SFONDI = {R.drawable.sfondo_0, R.drawable.sfondo_1, R.drawable.sfondo_2, R.drawable.sfondo_3,
            R.drawable.sfondo_4, R.drawable.sfondo_5, R.drawable.sfondo_6, R.drawable.sfondo_7, R.drawable.sfondo_8, R.drawable.sfondo_9};

    // ---------- Meteo ----------
    public static final String[] NOMI_MODO = {"Solo orologio", "Orologio e meteo"};
    public static final String[] NOMI_METEO_STILE = {"Compatto (☀️ 18°)", "Dettagliato (con città, max e min)"};
    public static final String[] NOMI_METEO_POS = {"Sotto l'ora", "Accanto alla data"};

    // ---------- Valori ----------
    public int modo = 1, font = 0, formatoOra = 0, formatoData = 0, posData = 0, allinea = 1,
            colore = 0, coloreData = 0, sfondo = 0, meteoStile = 0, meteoPos = 0,
            scala = 100, scalaData = 100, scalaMeteo = 100, spazio = 0, margine = 10, spostaX = 0, spostaY = 0;

    private static final String[] CHIAVI = {"modo", "font", "formatoOra", "formatoData", "posData", "allinea",
            "colore", "coloreData", "sfondo", "meteoStile", "meteoPos",
            "scala", "scalaData", "scalaMeteo", "spazio", "margine", "spostaX", "spostaY"};

    private int[] valori() {
        return new int[]{modo, font, formatoOra, formatoData, posData, allinea, colore, coloreData, sfondo, meteoStile, meteoPos,
                scala, scalaData, scalaMeteo, spazio, margine, spostaX, spostaY};
    }

    private void imposta(int[] v) {
        modo = v[0]; font = v[1]; formatoOra = v[2]; formatoData = v[3]; posData = v[4]; allinea = v[5];
        colore = v[6]; coloreData = v[7]; sfondo = v[8]; meteoStile = v[9]; meteoPos = v[10];
        scala = v[11]; scalaData = v[12]; scalaMeteo = v[13]; spazio = v[14]; margine = v[15]; spostaX = v[16]; spostaY = v[17];
    }

    public Impostazioni copia() {
        Impostazioni n = new Impostazioni();
        n.imposta(valori());
        return n;
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("widget2", Context.MODE_PRIVATE);
    }

    private static String prefisso(int id) {
        return id <= 0 ? "def_" : "w" + id + "_";
    }

    /** id <= 0 = impostazioni predefinite */
    public static Impostazioni carica(Context c, int id) {
        SharedPreferences p = prefs(c);
        String pre = prefisso(id);
        if (!p.contains(pre + "font")) pre = "def_";
        Impostazioni s = new Impostazioni();
        int[] v = s.valori();
        for (int i = 0; i < CHIAVI.length; i++) v[i] = p.getInt(pre + CHIAVI[i], v[i]);
        s.imposta(v);
        s.correggi();
        return s;
    }

    public void salva(Context c, int id) {
        SharedPreferences.Editor e = prefs(c).edit();
        String pre = prefisso(id);
        int[] v = valori();
        for (int i = 0; i < CHIAVI.length; i++) e.putInt(pre + CHIAVI[i], v[i]);
        e.apply();
    }

    public static void cancella(Context c, int id) {
        SharedPreferences.Editor e = prefs(c).edit();
        for (String k : CHIAVI) e.remove(prefisso(id) + k);
        e.apply();
    }

    private static int lim(int v, int a, int b) {
        return Math.max(a, Math.min(b, v));
    }

    private void correggi() {
        font = lim(font, 0, LAYOUT_OMBRA.length - 1);
        formatoOra = lim(formatoOra, 0, FORMATI_ORA.length - 1);
        formatoData = lim(formatoData, 0, NOMI_DATA.length - 1);
        colore = lim(colore, 0, COLORI.length - 1);
        coloreData = lim(coloreData, 0, COLORI.length);
        sfondo = lim(sfondo, 0, SFONDI.length - 1);
        allinea = lim(allinea, 0, 2);
        scala = lim(scala, 20, 300);
        scalaData = lim(scalaData, 40, 250);
        scalaMeteo = lim(scalaMeteo, 40, 250);
        spazio = lim(spazio, 0, 60);
        margine = lim(margine, 0, 60);
        spostaX = lim(spostaX, -150, 150);
        spostaY = lim(spostaY, -150, 150);
    }

    public void ripristinaMisure() {
        scala = 100; scalaData = 100; scalaMeteo = 100; spazio = 0; margine = 10; spostaX = 0; spostaY = 0;
    }

    // ---------- Temi ----------
    // {font, formatoOra, formatoData, posData, allinea, colore, coloreData(0=come l'ora, poi colore+1), sfondo, scalaData}
    public static final String[] NOMI_TEMI_APPLE = {
            "Blocco schermo", "Blocco sottile", "Blocco Serif", "Widget chiaro", "Widget scuro",
            "StandBy notte", "StandBy oro", "Blocco azzurro", "Widget grafite"};
    public static final int[][] TEMI_APPLE = {
            {8, 1, 7, 0, 1, 0, 0, 0, 100},
            {1, 1, 7, 0, 1, 0, 0, 0, 100},
            {4, 1, 7, 0, 1, 0, 0, 0, 100},
            {0, 1, 6, 0, 0, 1, 5, 4, 115},
            {0, 1, 6, 0, 0, 0, 5, 3, 115},
            {8, 1, 5, 0, 1, 4, 0, 5, 100},
            {8, 1, 8, 1, 1, 6, 3, 5, 110},
            {8, 1, 7, 0, 1, 8, 0, 0, 100},
            {10, 1, 7, 0, 0, 0, 3, 9, 105}};

    public static final String[] NOMI_TEMI_SAMSUNG = {
            "One UI", "One UI verticale", "One UI sottile", "Card vetro", "Card chiara",
            "Condensato", "Galaxy blu", "Elegante", "Sabbia", "Grafite arancio"};
    public static final int[][] TEMI_SAMSUNG = {
            {0, 0, 0, 0, 1, 0, 0, 0, 100},
            {8, 4, 0, 1, 0, 0, 0, 0, 100},
            {2, 0, 1, 1, 1, 0, 0, 0, 100},
            {0, 0, 0, 0, 0, 0, 11, 1, 105},
            {0, 0, 0, 0, 0, 1, 11, 4, 105},
            {3, 0, 2, 0, 1, 0, 4, 0, 100},
            {0, 0, 0, 1, 1, 0, 11, 7, 100},
            {4, 0, 1, 1, 2, 0, 0, 0, 100},
            {2, 0, 0, 0, 0, 1, 16, 8, 105},
            {8, 0, 2, 0, 1, 0, 6, 9, 100}};

    public void applicaTema(int[] t) {
        font = t[0]; formatoOra = t[1]; formatoData = t[2]; posData = t[3];
        allinea = t[4]; colore = t[5]; coloreData = t[6]; sfondo = t[7]; scalaData = t[8];
        correggi();
    }

    // ---------- Testo della data ----------
    public static String testoData(int formato) {
        Locale l = Locale.getDefault();
        Date d = new Date();
        switch (formato) {
            case 0: return maiuscoleParole(new SimpleDateFormat("EEE, d MMM", l).format(d).replace(".", ""));
            case 1: return primaMaiuscola(new SimpleDateFormat("EEEE d MMMM", l).format(d));
            case 2: return new SimpleDateFormat("EEE d MMM", l).format(d).replace(".", "").toUpperCase(l);
            case 3: return new SimpleDateFormat("dd/MM/yyyy", l).format(d);
            case 4: return primaMaiuscola(new SimpleDateFormat("EEEE", l).format(d));
            case 6: return new SimpleDateFormat("EEEE", l).format(d).toUpperCase(l);
            case 7: return new SimpleDateFormat("EEEE d MMMM", l).format(d).toLowerCase(l);
            case 8: return maiuscoleParole(new SimpleDateFormat("EEE d", l).format(d).replace(".", ""));
            default: return "";
        }
    }

    static String primaMaiuscola(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    static String maiuscoleParole(String s) {
        StringBuilder b = new StringBuilder();
        boolean inizio = true;
        for (char ch : s.toCharArray()) {
            b.append(inizio && Character.isLetter(ch) ? Character.toUpperCase(ch) : ch);
            inizio = ch == ' ';
        }
        return b.toString();
    }
}
