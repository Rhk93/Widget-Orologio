package it.paolicelli.widgetorologio;

// Copyright © Ignazio Paolicelli

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Impostazioni {

    public static final String[] NOMI_FONT = {
            "Classico", "Sottile", "Leggero", "Condensato", "Elegante (Serif)",
            "Digitale", "Corsivo", "Casual", "Extra grassetto", "Maiuscoletto", "Normale"};
    public static final String[] FAMIGLIE_FONT = {
            "sans-serif-medium", "sans-serif-thin", "sans-serif-light", "sans-serif-condensed", "serif",
            "monospace", "cursive", "casual", "sans-serif-black", "sans-serif-smallcaps", "sans-serif"};
    public static final int[] LAYOUT_FONT = {
            R.layout.widget_f0, R.layout.widget_f1, R.layout.widget_f2, R.layout.widget_f3, R.layout.widget_f4,
            R.layout.widget_f5, R.layout.widget_f6, R.layout.widget_f7, R.layout.widget_f8, R.layout.widget_f9, R.layout.widget_f10};

    public static final String[] NOMI_ORA = {"24 ore (09:41)", "24 ore (9:41)", "12 ore (9:41)", "Con i secondi", "Verticale (ore sopra, minuti sotto)"};
    public static final String[] FORMATI_ORA = {"HH:mm", "H:mm", "h:mm", "HH:mm:ss", "HH\nmm"};

    public static final String[] NOMI_DATA = {"Mar, 17 Nov", "Martedì 17 novembre", "MAR 17 NOV", "17/11/2026", "Solo il giorno (Martedì)", "Nessuna data"};
    public static final String[] NOMI_POS_DATA = {"Sopra l'ora", "Sotto l'ora"};
    public static final String[] NOMI_ALLINEA = {"A sinistra", "Al centro", "A destra"};

    public static final String[] NOMI_COLORI = {"Bianco", "Nero", "Oro", "Azzurro", "Rosa", "Verde menta", "Arancione", "Viola", "Rosso"};
    public static final int[] COLORI = {0xFFFFFFFF, 0xFF111111, 0xFFFFC83D, 0xFF7CC8FF, 0xFFFF8FC7, 0xFF7DF2B6, 0xFFFF9F43, 0xFFC39BFF, 0xFFFF5A5A};

    public static final String[] NOMI_SFONDO = {"Nessuno", "Scuro trasparente", "Chiaro trasparente", "Nero", "Blu notte", "Bianco"};
    public static final int[] SFONDI = {R.drawable.sfondo_nessuno, R.drawable.sfondo_scuro, R.drawable.sfondo_chiaro,
            R.drawable.sfondo_nero, R.drawable.sfondo_blu, R.drawable.sfondo_bianco};

    public static final String[] NOMI_DIM = {"Piccola", "Normale", "Grande", "Enorme"};
    public static final float[] DIM = {0.75f, 1f, 1.2f, 1.45f};

    public static final String[] NOMI_MODO = {"Solo orologio", "Orologio e meteo"};
    public static final String[] NOMI_METEO_STILE = {"Compatto (☀️ 18°)", "Dettagliato (con città, max e min)"};
    public static final String[] NOMI_METEO_POS = {"Sotto l'ora", "Accanto alla data"};

    public int modo = 1, font = 0, formatoOra = 0, formatoData = 0, posData = 0, allinea = 1,
            colore = 0, sfondo = 0, dimensione = 1, meteoStile = 0, meteoPos = 0;

    private static final String[] CHIAVI = {"modo", "font", "formatoOra", "formatoData", "posData", "allinea",
            "colore", "sfondo", "dimensione", "meteoStile", "meteoPos"};

    private int[] valori() {
        return new int[]{modo, font, formatoOra, formatoData, posData, allinea, colore, sfondo, dimensione, meteoStile, meteoPos};
    }

    private void imposta(int[] v) {
        modo = v[0]; font = v[1]; formatoOra = v[2]; formatoData = v[3]; posData = v[4]; allinea = v[5];
        colore = v[6]; sfondo = v[7]; dimensione = v[8]; meteoStile = v[9]; meteoPos = v[10];
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("widget", Context.MODE_PRIVATE);
    }

    private static String prefisso(int id) {
        return id <= 0 ? "def_" : "w" + id + "_";
    }

    /** id <= 0 = impostazioni predefinite */
    public static Impostazioni carica(Context c, int id) {
        SharedPreferences p = prefs(c);
        String pre = prefisso(id);
        if (!p.contains(pre + "font")) pre = "def_";
        Impostazioni s = new Impostazioni();
        int[] v = s.valori();
        for (int i = 0; i < CHIAVI.length; i++) v[i] = p.getInt(pre + CHIAVI[i], v[i]);
        s.imposta(v);
        s.correggi();
        return s;
    }

    public void salva(Context c, int id) {
        SharedPreferences.Editor e = prefs(c).edit();
        String pre = prefisso(id);
        int[] v = valori();
        for (int i = 0; i < CHIAVI.length; i++) e.putInt(pre + CHIAVI[i], v[i]);
        e.apply();
    }

    public static void cancella(Context c, int id) {
        SharedPreferences.Editor e = prefs(c).edit();
        for (String k : CHIAVI) e.remove(prefisso(id) + k);
        e.apply();
    }

    private void correggi() {
        if (font < 0 || font >= LAYOUT_FONT.length) font = 0;
        if (formatoOra < 0 || formatoOra >= FORMATI_ORA.length) formatoOra = 0;
        if (formatoData < 0 || formatoData >= NOMI_DATA.length) formatoData = 0;
        if (colore < 0 || colore >= COLORI.length) colore = 0;
        if (sfondo < 0 || sfondo >= SFONDI.length) sfondo = 0;
        if (dimensione < 0 || dimensione >= DIM.length) dimensione = 1;
        if (allinea < 0 || allinea > 2) allinea = 1;
    }

    /** Stili pronti: {font, formatoOra, formatoData, posData, allinea, colore, sfondo} */
    public static final String[] NOMI_STILI = {"Apple", "Apple Widget", "Apple StandBy", "Samsung", "Minimal", "Digitale", "Elegante", "Verticale", "Card",
            "Corsivo", "Neon", "Retrò", "Pastello", "Gigante", "Terminale", "Carta"};
    public static final int[][] STILI = {
            {8, 1, 1, 0, 1, 0, 0},
            {10, 1, 4, 0, 0, 0, 2},
            {8, 4, 5, 0, 1, 8, 3},
            {0, 0, 0, 0, 1, 0, 0},
            {1, 1, 1, 1, 1, 0, 0},
            {5, 3, 3, 1, 1, 5, 3},
            {4, 0, 1, 1, 1, 2, 0},
            {8, 4, 0, 1, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 1},
            {6, 0, 1, 1, 1, 0, 0},
            {3, 0, 2, 0, 1, 7, 4},
            {4, 1, 1, 1, 1, 2, 4},
            {2, 0, 0, 1, 1, 4, 2},
            {8, 4, 4, 1, 1, 3, 0},
            {5, 0, 3, 0, 0, 5, 3},
            {4, 1, 1, 0, 0, 1, 5}};

    public void applicaStile(int n) {
        int[] st = STILI[n];
        font = st[0]; formatoOra = st[1]; formatoData = st[2]; posData = st[3];
        allinea = st[4]; colore = st[5]; sfondo = st[6];
    }

    public static String testoData(int formato) {
        Locale l = Locale.getDefault();
        Date d = new Date();
        switch (formato) {
            case 0: return maiuscoleParole(new SimpleDateFormat("EEE, d MMM", l).format(d).replace(".", ""));
            case 1: return primaMaiuscola(new SimpleDateFormat("EEEE d MMMM", l).format(d));
            case 2: return new SimpleDateFormat("EEE d MMM", l).format(d).replace(".", "").toUpperCase(l);
            case 3: return new SimpleDateFormat("dd/MM/yyyy", l).format(d);
            case 4: return primaMaiuscola(new SimpleDateFormat("EEEE", l).format(d));
            default: return "";
        }
    }

    static String primaMaiuscola(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    static String maiuscoleParole(String s) {
        StringBuilder b = new StringBuilder();
        boolean inizio = true;
        for (char ch : s.toCharArray()) {
            b.append(inizio && Character.isLetter(ch) ? Character.toUpperCase(ch) : ch);
            inizio = ch == ' ';
        }
        return b.toString();
    }
}
